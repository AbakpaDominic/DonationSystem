<?php

require_once __DIR__ . '/vendor/squizlabs/php_codesniffer/src/Util/Tokens.php';
require_once __DIR__ . '/vendor/autoload.php';
